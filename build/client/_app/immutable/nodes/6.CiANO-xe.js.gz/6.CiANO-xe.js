import{t as v,j as rt,a as d,c as it}from"../chunks/BigvG9Gq.js";import{i as ot}from"../chunks/CwHX7vui.js";import{p as st,o as nt,f as Q,t as b,b as pt,d as l,c as e,Q as dt,n as xt,$ as ct,r as t,g as x}from"../chunks/CZu2fjw8.js";import{s as _}from"../chunks/B2K67hgT.js";import{p as vt,i as ht}from"../chunks/Bl_OthJ0.js";import{e as mt,F as gt,a as ft}from"../chunks/BZ0x716o.js";import{h as ut}from"../chunks/CYbkLdh3.js";import{a as c}from"../chunks/DA4jBAQu.js";import{H as wt}from"../chunks/Bo1b50gL.js";const bt=!1,qt=Object.freeze(Object.defineProperty({__proto__:null,prerender:bt},Symbol.toStringTag,{value:"Module"}));var _t=v(`<meta name="description" content=""> <style>/* Standar heading sizes (mobile-first) */
        h1 {
          font-size: 2.5rem !important;  /* 40px */
          line-height: 1.2;
        }

        h2 {
            font-size: 2rem !important;    /* 32px */
            line-height: 1.3;
        }

        h3 {
          font-size: 1.75rem !important; /* 28px */
          line-height: 1.4;
        
          margin: 0 0 1rem;
        }
      
        h4 {
            font-size: 1.5rem !important;  /* 24px */
            line-height: 1.5;
        }
      
        h5 {
            font-size: 1.25rem !important; /* 20px */
            line-height: 1.6;
        }
    
        h6 {
            font-size: 1rem !important;   /* 16px */
            line-height: 1.7;
            letter-spacing: 0.05em;
        }
      
        /* Responsive adjustments (opsional) */
        @media (min-width: 768px) {
          h1 { font-size: 3rem !important; }    /* 48px */
          h2 { font-size: 2.5rem !important; }  /* 40px */
          h3 { font-size: 2rem !important; }    /* 32px */
        }</style>`,1),yt=v('<span class="hidden"></span>'),kt=v('<div class="swiper-slide"><div class="grid grid-rows 2xl:gap-8 xl:gap-6 gap-4 h-full w-full"><img class="aspect-[9/11] object-cover object-center " alt=""> <ul class="flex flex-col 2xl:gap-4 xl:gap-3 gap-3"><li class="text-gold font-marcel 2xl:text-2xl xl:text-xl text-xl md:line-clamp-2"> </li></ul> <div class="flex 2xl:gap-4 xl:gap-3 gap-2"><a data-sveltekit-reload="" class="w-max flex items-center font-manrope text-base pb-1 capitalize text-gold border-gold border-b border-solid hover:text-secondary hover:border-secondary transition-all duration-300">read more</a></div></div></div>'),Ft=v('<!> <section class="h-full w-full bg-lightbg xl:pt-0 pt-44 px-0"><div class="h-full w-full xl:block hidden"><img class="h-screen w-full object-cover md:aspect-[16/10] aspect-square" alt="Hero images"></div> <div class="container 2xl:px-28 xl:px-24 md:px-12 relative h-full w-full "><img class="h-full w-full object-cover md:aspect-[16/10] aspect-square xl:hidden block" alt="Hero images"> <p class="2xl:pt-14 pt-10 text-secondary italic"> </p> <h1 class="font-marcel 2xl:!text-5xl xl:!text-3xl md:!text-2xl !text-xl text-gold 2xl:pt-8 xl:pt-5 pt-4"> </h1> <div id="desc" class="font-manrope text-secondary 2xl:pt-10 xl:pt-8 pt-6"><!></div></div></section> <section class="h-full w-full bg-lightbg 2xl:py-16 xl:py-14 py-28 2xl:px-28 xl:px-24 px-12"><div class="relative xl:border-none border-t-2 2xl:pt-16 xl:pt-14 pt-10 border-gold border-solid flex flex-col xl:flex-row 2xl:gap-14 xl:gap-12 gap-10"><div class="relative w-full xl:w-3/12 xl:flex xl:flex-col xl:justify-center"><div class="absolute top-0 inset-x-0"><div class="items-center 2xl:gap-8 xl:gap-6 gap-4 !w-auto relative justify-center xl:flex hidden"><span class="swiper-button-prev-blogdetail !m-0 !left-0 !right-0 2xl:!w-22 xl:!h-16 xl:!w-16 md:!h-16 md:!w-16 !h-14 !w-14 !relative cursor-pointer after:!content-none group"><svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full transition-opacity duration-300 ease-in-out group-hover:opacity-0" viewBox="0 0 90 90" fill="none"><rect x="0.75" y="0.75" width="88.5" height="88.5" rx="44.25" stroke="#AF9F8D" stroke-width="1.5"></rect><path d="M37.9367 57L27 45M27 45L37.9367 33M27 45H62" stroke="#AF9F8D" stroke-width="1.5"></path></svg> <svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-in-out" viewBox="0 0 90 90" fill="none"><rect width="90" height="90" rx="45" fill="#AF9F8D"></rect><path d="M37.9367 57L27 45M27 45L37.9367 33M27 45H62" stroke="white" stroke-width="1.5"></path></svg></span> <span class="swiper-button-next-blogdetail !m-0 !left-0 !right-0 2xl:!h-22 2xl:!w-22 xl:!h-16 xl:!w-16 md:!h-16 md:!w-16 !h-14 !w-14 !relative cursor-pointer after:!content-none group"><svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full transition-opacity duration-300 ease-in-out group-hover:opacity-0" viewBox="0 0 90 90" fill="none"><rect x="0.75" y="0.75" width="88.5" height="88.5" rx="44.25" stroke="#AF9F8D" stroke-width="1.5"></rect><path d="M51.0633 33L62 45M62 45L51.0633 57M62 45H27" stroke="#AF9F8D" stroke-width="1.5"></path></svg> <svg xmlns="http://www.w3.org/2000/svg" class="w-full h-full absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-in-out" viewBox="0 0 90 90" fill="none"><rect width="90" height="90" rx="45" fill="#AF9F8D"></rect><path d="M51.0633 33L62 45M62 45L51.0633 57M62 45H27" stroke="white" stroke-width="1.5"></path></svg></span></div></div> <p class="text-gold font-marcel text-center 2xl:text-4xl xl:text-4xl text-3xl italic">Other Blog</p></div> <div class="relative h-full w-full xl:w-9/12"><div class="swiper myBlogdetailSwiper"><div class="swiper-wrapper"></div></div></div></div></section> <!>',1);function Ot(E,y){var S,q,O,$,I;st(y,!1);let n=vt(y,"data",8),k=(S=n())==null?void 0:S.info,G=(q=n())==null?void 0:q.offers,J=(O=n())==null?void 0:O.accommodation,K=($=n())==null?void 0:$.blog,r=(I=n())==null?void 0:I.blogDetail;function N(o){const a=new Date(o);return new Intl.DateTimeFormat("id-ID",{day:"2-digit",month:"long",year:"numeric"}).format(a)}nt(()=>{}),ot();var F=Ft();rt(o=>{var a=_t();xt(2),b(()=>ct.title=`${r.name??""} - Lembongan Beach Club and Resort`),d(o,a)});var M=Q(F);wt(M,{info:k,offers:G,rooms:J});var h=l(M,2),m=e(h),U=e(m);t(m);var z=l(m,2),D=e(z),g=l(D,2),V=e(g);t(g);var f=l(g,2),W=e(f,!0);t(f);var j=l(f,2),X=e(j);ut(X,()=>r.description),t(j),t(z),t(h);var u=l(h,2),L=e(u),B=l(e(L),2),H=e(B),A=e(H);mt(A,5,()=>K,ft,(o,a)=>{var p=it(),Z=Q(p);{var tt=s=>{var i=yt();d(s,i)},et=s=>{var i=kt(),R=e(i),T=e(R),w=l(T,2),C=e(w),at=e(C,!0);t(C),t(w);var P=l(w,2),lt=e(P);t(P),t(R),t(i),b(()=>{c(T,"src",x(a).featured_images[0].path),_(at,x(a).name),c(lt,"href",`/blog/${x(a).slug??""}`)}),d(s,i)};ht(Z,s=>{var i;((i=x(a))==null?void 0:i.slug)==r.slug?s(tt):s(et,!1)})}d(o,p)}),t(A),t(H),t(B),t(L),t(u);var Y=l(u,2);gt(Y,{info:k}),b(o=>{var a,p;c(U,"src",((a=r.featured_images[0])==null?void 0:a.path)??""),c(D,"src",((p=r.featured_images[0])==null?void 0:p.path)??""),_(V,`${r.admin??""} - ${o??""}`),_(W,r.name)},[()=>N(r.date)],dt),d(E,F),pt()}export{Ot as component,qt as universal};
